package Latihanjava;

public class Latihan1 {
    public static void main(String[] args) {
        // Tipe data bilangan bulat
        byte stokToko = 120;
        short jumlahBarang = 5000;
        int hargaBarang = 150000;
        long totalPendapatan = 2000000000L;

        // Tipe data pecahan
        float diskon = 0.15f;
        double hargaSetelahDiskon = hargaBarang - (hargaBarang * diskon);

        // Tipe data karakter
        char kodeKategori = 'E';  // E = Elektronik

        // Tipe data boolean
        boolean tersedia = true;

        // Tipe data String
        String namaBarang = "Headphone Bluetooth";

        // Menampilkan data barang
        System.out.println("=== DATA BARANG DI TOKO ===");
        System.out.println("Nama Barang           : " + namaBarang);
        System.out.println("Kategori Barang (Kode): " + kodeKategori);
        System.out.println("Stok di Toko          : " + stokToko);
        System.out.println("Jumlah Barang Masuk   : " + jumlahBarang);
        System.out.println("Harga Barang          : Rp " + hargaBarang);
        System.out.println("Diskon                : " + (diskon * 100) + "%");
        System.out.println("Harga Setelah Diskon  : Rp " + hargaSetelahDiskon);
        System.out.println("Total Pendapatan Toko : Rp " + totalPendapatan);
        System.out.println("Barang Tersedia?      : " + tersedia);
    }
}
