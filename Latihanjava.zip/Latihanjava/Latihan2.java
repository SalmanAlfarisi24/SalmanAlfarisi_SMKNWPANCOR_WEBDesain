package Latihanjava;

public class Latihan2 {
    public static void main(String[] args) {
        // Deklarasi tipe data & variabel
        String nama = "Rani Putri";
        String alamat = "Jl. Merdeka No. 45, Jakarta";
        byte umur = 20;
        short tinggi = 160;
        int beratBadan = 55;
        long noKTP = 3210012345678900L;
        float nilaiIPK = 3.75f;
        double tinggiPresisi = 160.567;
        char jenisKelamin = 'P';  // P = Perempuan, L = Laki-laki
        boolean statusAktif = true;

        // Menampilkan biodata
        System.out.println("=== BIODATA DIRI ===");
        System.out.println("Nama            : " + nama);
        System.out.println("Alamat          : " + alamat);
        System.out.println("Umur            : " + umur + " tahun");
        System.out.println("Tinggi Badan    : " + tinggi + " cm");
        System.out.println("Tinggi Presisi  : " + tinggiPresisi + " cm");
        System.out.println("Berat Badan     : " + beratBadan + " kg");
        System.out.println("Nomor KTP       : " + noKTP);
        System.out.println("Nilai IPK       : " + nilaiIPK);
        System.out.println("Jenis Kelamin   : " + jenisKelamin);
        System.out.println("Status Aktif    : " + statusAktif);
    }
}
