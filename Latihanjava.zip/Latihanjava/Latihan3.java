package Latihanjava;

public class Latihan3 {
	
	public static void main(String[] args) {
		// Deklarasi variabel dan tipe data
		String nama = "Rani Putri";
		String alamat = "Jl. Merdeka No. 45, Jakarta";
		char jenisKelamin = 'P'; // P = Perempuan, L = Laki-laki
		int umur = 20;
		String jurusan = "Informatika";
		double ipk = 3.85;
		boolean statusAktif = true;
		
		// Menampilkan data mahasiswa
		System.out.println("=== Data Mahasiswa ===");
		System.out.println("Nama            : " + nama);
		System.out.println("Alamat          : " + alamat);
		System.out.println("Jenis Kelamin   : " + jenisKelamin);
		System.out.println("Umur            : " + umur + " tahun");
		System.out.println("Jurusan         : " + jurusan);
		System.out.println("IPK             : " + ipk);
    System.out.println("Status Aktif    : " + statusAktif);
  }
}